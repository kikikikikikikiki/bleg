import math
import pygame

def draw():
    screen = pygame.
