import pygame
import math
pygame.init()

surface = pygame.display.set_mode( (800,800) )
clock = pygame.time.Clock()

def tree0():
    tree0()
    tree0()


def loop():

    tree0()
